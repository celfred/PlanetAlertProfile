<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "PlanetAlert Profile", 
	'summary' => "v1.1.0 ProcessWire profile for Planet Alert", 
	'screenshot' => ""
	);
