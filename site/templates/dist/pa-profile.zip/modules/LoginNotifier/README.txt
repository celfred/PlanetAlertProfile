Login Notifier module for ProcessWire 2.1+

Provides ability to send an email, ping a URL or save a log entry when a login occurs.

To install, place this file at /site/modules/LoginNotifier.module

After you click the install button in Admin > Modules, you will get a configuration screen. 

ProcessWire 2.x 
Copyright (C) 2013 by Ryan Cramer 
Licensed under GNU/GPL v2

http://processwire.com

