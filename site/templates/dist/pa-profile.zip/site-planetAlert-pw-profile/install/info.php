<?php if(!defined("PROCESSWIRE_INSTALL")) die();
$info = array(
	'title' => "Planet Alert ProcessWire Profile (v1.0)", 
	'summary' => "Start a fresh Planet Alert website with ProcessWire. (v1.0)", 
	'screenshot' => "logo_big.png"
	);
