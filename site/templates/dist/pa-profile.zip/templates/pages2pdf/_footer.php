<?php

echo 'Page générée le '.date("d/m/Y \à H:i:s");

?>
