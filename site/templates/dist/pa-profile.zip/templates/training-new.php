<?php namespace ProcessWire;
if (!$config->ajax) {
  include("./head.inc"); 

  $limitDate  = new \DateTime("-1 year");
  $limitDate = strtotime($limitDate->format('Y-m-d'));

  if (isset($player) && $user->isLoggedin() || $user->isSuperuser() || $user->hasRole('teacher')) {
    // Test if player has unlocked Memory helmet (only training equipment for the moment)
    // or if admin has forced it in Team options
    if ($user->isSuperuser() || $user->hasRole('teacher') || $player->team->forceHelmet == 1) {
      $helmet = $pages->get("name=memory-helmet");
      if ($user->isSuperuser() || $user->hasRole('teacher')) {
        $player = $pages->get("parent.name=players, name=test");
        $request = false;
      }
    } else {
      $helmet = $player->equipment->get("name=memory-helmet");
    }
    if ($helmet) { // Display training catalogue
      $out = '<div>';
      // Set all available monsters
      if ($user->hasRole('player')) {
        // Check if player has the Visualizer (or forced by admin)
        if ($player->equipment->has("name~=visualizer") || $player->team->forceVisualizer == 1) {
          $allMonsters = $pages->find("parent.name=monsters, template=exercise, exerciseOwner.singleTeacher=$headTeacher, exerciseOwner.publish=1")->sort("name");
          $allMonstersNb = $allMonsters->count();
        } else {
          $allMonsters = $pages->find("parent.name=monsters, template=exercise, exerciseOwner.singleTeacher=$headTeacher, exerciseOwner.publish=1, special=0")->sort("name");
          $hiddenMonstersNb = $pages->find("parent.name=monsters, template=exercise, (exerciseOwner.singleTeacher=$headTeacher, exerciseOwner.publish=1), special=1")->count();
        }
        // Check if fightRequest
        if ($player->fight_request == 0) { $request = false; } else { $request = $player->fight_request; }
      } else if ($user->hasRole('teacher')) {
        $allMonsters = $pages->find("parent.name=monsters, template=exercise, (created_users_id=$user->id),(exerciseOwner.singleTeacher=$user,exerciseOwner.publish=1, summary!='')")->sort("name");
      } else if ($user->isSuperuser()) {
        $allMonsters = $pages->find("parent.name=monsters, template=exercise, sort=name, include=all");
      }
      // Store allMonsters in session cache on 1st page load
      $cache->save("monstersList_".$user->name, $allMonsters);
      $allMonstersNb = $allMonsters->count();
      $out .= '<div class="well">';
      $out .= '<h2 class="text-center">';
        $out .= '<span class="pull-left glyphicon glyphicon-question-sign" data-toggle="tooltip" data-html="true" title="'.$page->summary.'"></span>';
        $out .= '<span class="blink">';
          $out .= __("Program your helmet !");
        $out .= "</span>";
        if ($helmet->image) {
          $out .= '<img class="pull-right" src="'.$helmet->image->url.'" alt="Helmet" />';
        }
      $out .= '</h2>';
      $out .= '<p class="text-center">';
      $detector = $pages->get("name=electronic-Visualizer");
      $link = '<a href="'.$detector->url.'">'.$detector->title.'</a>';
      if (!isset($hiddenMonstersNb)) {
        $out .= sprintf(__('There are %1$s detected monsters thanks to your %2$s.'), $allMonstersNb, $link);
      } else {
        $out .= sprintf(__('There are %d detected monsters.'), $allMonstersNb);
        $out .= sprintf(__('%1$s monsters are absent because you don\'t have the %2$s.'), $hiddenMonstersNb, $link);
      }
      $out .= '</p>';
      if (isset($hiddenMonstersNb)) { // Display helpAlert for Electronic visualizer
        $helpAlert = true;
        $helpTitle = __("Some monsters are absent !");
        $helpMessage = '<img src="'.$pages->get("name~=visualizer")->image->getCrop("small")->url.'" alt="image" /> ';
        $helpMessage .= '<h4>'.sprintf(__('%1$s monsters are absent because you don\'t have the %2$s.'), $hiddenMonstersNb, $link).'</h4>';
      }
      include("./helpAlert.inc.php"); 
      $allCategories = $cache->get('cache__allTrainCategories', $templates->get("name=category"), function($pages) {
        return $pages->find("parent.name=topics, sort=name");
      });
      $out .= '<section class="configHelmet">';
      if ($input->urlSegment1 == '') { // No selection
          $out .= '<div class="frame">';
            $out .= __("Today's challenge !"); // TODO
            $out .= ' TODO ';
          $out .= '</div>';
          $out .= '<div class="frame">';
            $out .= __("Quick selection ?").' ↓ ';
            $out .= '<div class="btn-toolbar">';
              $out .= '<div class="btn-group btn-group-lg" role="group">';
                /* $out .= '<a href="'.$page->url.'random" class="btn btn-primary pgHelmet">'.__("Personal recommandation").'</a>&nbsp;'; // TODO */
                $out .= '<a href="'.$page->url.'random" class="btn btn-primary pgHelmet">'.__("Random selection").'</a>&nbsp;';
                $out .= '<a href="'.$page->url.'never" class="btn btn-primary pgHelmet">'.__("Never trained").'</a>';
              $out .= '</div>';
              $out .= '<div class="btn-group btn-group-lg" role="group">';
                $out .= '<a href="'.$page->url.'level/1" class="btn btn-primary pgHelmet">Level 1</a>';
                $out .= '<a href="'.$page->url.'level/2" class="btn btn-primary pgHelmet">Level 2</a>';
                $out .= '<a href="'.$page->url.'level/3" class="btn btn-primary pgHelmet">Level 3</a>';
              $out .= '</div>';
              $out .= '<div class="btn-group btn-group-lg" role="group">';
                $out .= '<button type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">';
                $out .= __("Name selection").' <span class="caret"></span>';
                $out .= '</button>';
                $out .= '<ul class="dropdown-menu monsterSelection">';
                  $allCat = [];
                  foreach($allMonsters as $m) {
                    $out .= '<li><a class="pgHelmet" href="'.$page->url.'monster/'.$m->id.'">'.$m->title.'</a></li>';
                    foreach($m->topic as $c){
                      if (!in_array($c->title, $allCat)) {
                        array_push($allCat, $c->title);
                      }
                    }
                    sort($allCat);
                  }
                $out .= '</ul>';
              $out .= '</div>';
            $out .= '</div>';
          $out .= '</div>';
          $out .= '<div class="frame">';
            $out .= __("Topic selection ?").' ↓';
            $out .= '<ul class="list list-unstyled col6">';
              foreach($allCat as $c) {
                $out .= '<li class="text-left"><a href="'.$page->url.$sanitizer->pageName($c).'" class="label label-danger pgHelmet topics">'.$c.'</a></li>';
              }
            $out .= '</ul>';
          $out .= '</div>';
      }
      $out .= '</section>';

      $out .= '<section id="trainingList" class="row" data-href="'.$page->url.'"></section>';

      echo $out;

      echo '</div>';
      echo '</div>';
    }
  } else {
    echo $noAuthMessage;
  }

  include("./foot.inc"); 
} else { // Load selected training possibilities
  if (!$user->isSuperuser()) {
    $headTeacher = getHeadTeacher($user);
    $user->language = $headTeacher->language;
    if ($user->hasRole('player')) { // Get logged in player
      $player = $pages->get("template=player, login=$user->name");
      $player->of(false);
    } else {
      $player = $pages->get("template=player, name=test");
    }
  } else {
    $player = $pages->get("template=player, name=test");
  }
  $allCachedMonsters = $cache->get("monstersList_".$user->name); // Read from cache after 1st page load
  switch($input->urlSegment1) {
    case 'random' :
      $allMonsters = $allCachedMonsters->findRandom(3)->sort("level");
      $title = '';
      break;
    case 'level' :
      $level = $input->urlSegment2;
      $selector = 'level='.$level;
      $allMonsters = $allCachedMonsters->find($selector)->sort("title");
      $title = '<h3>'.sprintf("%d results",$allMonsters->count()).'</h3>'; // TODO plural
      break;
    case 'monster' :
      $monsterId = $input->urlSegment2;
      $selector = 'id='.$monsterId;
      $allMonsters = $allCachedMonsters->find($selector);
      $title = '';
      break;
    case 'never' :
      $tmpCache = $player->children()->get("name=tmp");
      $allTrainedIds = [];
      foreach($tmpCache->tmpMonstersActivity as $p) {
        array_push($allTrainedIds, $p->monster->id);
      }
      $allTrainedIds = implode('|', $allTrainedIds);
      $selector = 'id!='.$allTrainedIds;
      $allMonsters = $allCachedMonsters->find($selector)->sort("level");
      $title = '<h3>'.sprintf("%d results",$allMonsters->count()).'</h3>'; // TODO plural
      break;
    default :
      $selector = 'topic.name='.$input->urlSegment1;
      $allMonsters = $allCachedMonsters->find($selector)->sort("level");
      $title = '<h3>'.sprintf("%d results",$allMonsters->count()).'</h3>'; // TODO plural
  }

  $out = '';
  $out .= '<button id="configHelmetBtn" class="btn btn-default btn-block"><span class="glyphicon glyphicon-cog"></span> '.__("Show/Hide program options").'</button>';
  $limitDate  = new \DateTime("-1 year");
  $limitDate = strtotime($limitDate->format('Y-m-d'));
  // Check if fightRequest
  if ($player->fight_request == 0) { $request = false; } else { $request = $player->fight_request; }
  $notAvailable = new pageArray();
    $out .= '<div class="container">';
    $out .= '<section class="row">';
      $today = new \DateTime("today");
      $out .= $title;
      foreach($allMonsters as $m) {
        $topics = $m->topic->implode(', ', '{title}');
          $m->of(false);
          if ($user->hasRole('player')) { // Prepare player's training possibilities
            setMonster($player, $m);
          }
          if ($user->hasRole("teacher") || $user->isSuperuser()) { // Never trained (for admin or teachers)
            $m->isTrainable = 1;
            $m->lastTrainingInterval = -1;
            $m->waitForTrain = 0;
          }
          if ($m->bestTrainedPlayerId != 0) {
            $bestTrained = $pages->get($m->bestTrainedPlayerId);
            $m->bestTrainedTitle = $bestTrained->title;
            $m->bestTrainedTeam = $bestTrained->team->title;
            if ($m->bestTrainedPlayerId == $player->id) {
              $m->isBestTrained = true;
            } else {
              $m->isBestTrained = false;
            }
          }
          if ($m->bestTimePlayerId != 0) {
            $master = $pages->get($m->bestTimePlayerId);
            $m->bestTimePlayerTitle = $master->title;
            $m->bestTimeTeam = $master->team->title;
            if ($m->bestTrainedPlayerId == $player->id) {
              $m->isMaster = true;
            } else {
              $m->isMaster = false;
            }
          }
          switch($m->level) {
            case '1' : $class = 'success'; break;
            case '2' : $class = 'warning'; break;
            case '3' : $class = 'danger'; break;
            default : $class = 'primary';
          }
          if ($m->isTrainable == 1) {
            $out .= '<div class="col-md-4">';
              $out .= '<div class="monsterPanel">';
              $out .= '<div class="actionBar lead col-md-12">';
              $out .= '<span class="badge pull-left">'.__("Level").' '.$m->level.'</span>';
              // Find # of days compared to today to set 'New' indicator
              $date2 = new \DateTime(date("Y-m-d", $m->published));
              $interval = $today->diff($date2);
              if ($interval->days < 7) {
                $out .= ' <span class="badge">'.__("New").'</span>';
              }
              if ($m->special) {
                $out .= ' <span class="badge">'.__("Detected").' !</span>';
              }
              $out .= ' <span>'.$m->title.'</span>';
              $out .= '<span class="pull-right">';
                $out .= ' <a class="btn btn-primary btn-lg" href="'.$m->url.'train"><i class="glyphicon glyphicon-headphones" data-toggle="tooltip" title="'.__("Put the helmet on !").'" onmouseenter="$(this).tooltip(\'show\');"></i></a>';
                $formerRequest = $pages->get("has_parent=$player, template=event, task.name=fight-vv, inClass=1, refPage=$m, date>$limitDate");
                if ($formerRequest->id) {
                  $out .= ' <span class="glyphicon glyphicon-ok" data-toggle="tooltip" title="'.__('You have already defeated this monster in the previous year.').'" onmouseenter="$(this).tooltip(\'show\');"></span>';
                } else {
                  if ($request == 0) {
                    $msg = sprintf(__("Fight request for %s"), $m->title);
                    $out .= ' <span><a class="btn btn-danger btn-lg fightRequestConfirm" href="'.$page->url.'" data-href="'.$pages->get("name=submitforms")->url.'?form=fightRequest&monsterId='.$m->id.'&playerId='.$player->id.'" data-msg="'.$msg.'" data-reload="true"><i class="glyphicon glyphicon-education" data-toggle="tooltip" title="'.__("Ask teacher for an in-class Fight!").'" onmouseenter="$(this).tooltip(\'show\');"></i></a></span>';
                  } else if ($request == $m->id) {
                    $out .= ' <span class="glyphicon glyphicon-ok-circle" data-toggle="tooltip" title="'.__('Your teacher has already been warned about this request.').'" onmouseenter="$(this).tooltip(\'show\');"></span>';
                  }
                }
                $out .= '</span>';
              $out .= '</div>';
              $out .= '<div class="row">';
              $out .= '<div class="col-md-4">';
                $out .= '<img class="img-thumbnail" src="'.$m->image->first()->getCrop("thumbnail")->url.'" title="" alt="no-img" />';
              $out .= '</div>';
              $out .= '<div class="clearfix visible-md-block"></div>';
              $out .= '<div class="col-md-8 monsterPanelBody">';
              $out .= '<p>';
                $out .= __("UT gained").' : ';
                if (isset($player)) {
                  if ($m->utGain > 0) {
                    $out .= '<span class="label label-success"><span class="glyphicon glyphicon-thumbs-up"></span> +'.$m->utGain.'</span> ';
                  } else {
                    $out .= '<span class="label label-danger"><span class="glyphicon glyphicon-thumbs-down"></span> 0</span> ';
                  }
                }
              $out .= '</p>';
              $out .= '<p>';
                $out .= __("Last training session").' : ';
                if (isset($player)) {
                  if ($m->lastTrainingInterval != '-1') {
                    $out .= $m->lastTrainingInterval;
                  } else {
                    $out .= '-';
                  }
                }
              $out .= '</p>';
              $out .= '<hr />';
              $out .= '<p>';
                $out .= '<span>'.__("Most trained").' : ';
                if ($m->bestTrainedPlayerId != 0) {
                  if ($m->isBestTrained) { $class = 'success'; } else { $class = 'primary'; }
                  $out .= '<span class="label label-'.$class.'">'.$m->best.' '.__("UT").' - '.$m->bestTrainedTitle.' ['.$m->bestTrainedTeam.']</span>';
                } else {
                  $out .= __("Nobody yet.");
                }
                $out .= '</span>';
              $out .= '</p>';
              $out .= '<p>';
                $out .= '<span>'.__("Master time").' : ';
                if ($m->bestTimePlayerTitle) {
                  if ($m->isMaster) { $class = 'success'; } else { $class = 'primary'; }
                  $out .= '<span class="label label-'.$class.'">'.ms2string($m->masterTime).' '.__('by').' '.$m->bestTimePlayerTitle.' ['.$m->bestTimeTeam.']</span>';
                } else {
                  $out .= __("Nobody yet.");
                }
                $out .= '</span>';
              $out .= '</p>';
              $out .= '<hr />';
              $out .= '<p>';
                $out .= __("Exercise type").' → '.$m->type->title;
                if ($m->type->summary != '') {
                  $tooltip = $m->type->summary;
                } else {
                  if ($m->type->getLanguageValue($french, 'summary') != '') {
                    $tooltip = $m->type->getLanguageValue($french, 'summary');
                  }
                }
                $out .= ' <span class="glyphicon glyphicon-question-sign" data-toggle="tooltip" title="'.$tooltip.'" onmouseenter="$(this).tooltip(\'show\');"></span>';
              $out .= '</p>';
              $out .= '</div>'; // col-md-9
              $out .= '</div>'; // row
              $out .= '<div class="footerBar">';
              if ($m->summary != '') {
                $out .= ' → <span>'.$m->summary.'</span> ';
              } else {
                if ($m->getLanguageValue($french, 'summary') != '') {
                  $out .= ' → <span>'.$m->getLanguageValue($french, 'summary').'</span> ';
                }
              }
              // Data preview
              $exData = $m->exData;
              $allLines = preg_split('/$\r|\n/', $sanitizer->entitiesMarkdown($exData));
              $listWords = prepareListWords($allLines, $m->type->name);
              $out .= ' <span class="glyphicon glyphicon-eye-open" data-toggle="tooltip" data-html="true" title="'.$listWords.'" onmouseenter="$(this).tooltip(\'show\');"></span>';
              $out .= '</div>';
              $out .= '</div>'; // monsterDiv
              $out .= '<div class="clearfix visible-md-block"></div>';
            $out .= '</div>'; // col-md-4
          } else {
            $notAvailable->add($m);
          }
        $out .= '<div class="clearfix visible-md-block"></div>';
      }
    $out .= '</section>'; // row
    if ($notAvailable->count() > 0) { // TODO List them
      $out .= '<section class="row">';
        $out .= '<h3>'.__("Not available").' ('.$notAvailable->count().') :</h3>';
        $out .= '<ul>';
          foreach($notAvailable as $m) { // TODO : Thumbnail ? Last train ?UT gained ?...
            if ($m->waitForTrain == 1) {
              $out .= '<li>'.$m->title.' → <span class="label label-success">'.__("Available tomorrow !").'</span></li>';
            } else {
              $out .= '<li>'.$m->title.' → <span class="label label-danger">'.sprintf(__("Available in %d day·s"), $m->waitForTrain).'</span></li>';
            }
          }
        $out .= '</ul>';
      $out .= '</section>';
    }
  $out .= '</div>'; // container

  /* $out .= '<table id="trainingTable" class="table table-condensed table-hover">'; */
  /*   $out .= '<thead>'; */
  /*   $out .= '<tr>'; */
  /*   $out .= '<th>'.__("Name").'</th>'; */
  /*   $out .= '<th>'.__("Level").'</th>'; */
  /*   $out .= '<th style="width:250px;">'.__("Summary").'</th>'; */
  /*   $out .= '<th>'.__("U.T. gained").'</th>'; */
  /*   $out .= '<th>'.__("Last training session").'</th>'; */
  /*   $out .= '<th>'.__("Actions"); */
  /*   $out .= ' <i class="glyphicon glyphicon-info-sign" data-toggle="tooltip" data-html="true" title="- '.__('Fight requests require at least +1UT on a monster<br />- Limited to 1 fight request').'"></i></th>'; */
  /*   $out .= '<th>'.__("Most trained player").'</th>'; */
  /*   $out .= '<th>'.__("Master time").'</th>'; */
  /*   $out .= '</tr>'; */
  /*   $out .= '</thead>'; */
  /*   $out .= '<tbody>'; */
  /*   $today = new \DateTime("today"); */
  /*   foreach($allMonsters as $m) { */
  /*     $m->of(false); */
  /*     if ($user->hasRole('player')) { */
  /*       // Prepare player's training possibilities */
  /*       setMonster($player, $m); */
  /*     } */
  /*     if ($user->hasRole("teacher")) { */
  /*       // Never trained (for admin) */
  /*       $m->isTrainable = 1; */
  /*       $m->lastTrainingInterval = -1; */
  /*       $m->waitForTrain = 0; */
  /*     } */
  /*     if ($m->bestTrainedPlayerId != 0) { */
  /*       $bestTrained = $pages->get($m->bestTrainedPlayerId); */
  /*       $m->bestTrainedTitle = $bestTrained->title; */
  /*       $m->bestTrainedTeam = $bestTrained->team->title; */
  /*       if ($m->bestTrainedPlayerId == $player->id) { */
  /*         $m->isBestTrained = true; */
  /*       } else { */
  /*         $m->isBestTrained = false; */
  /*       } */
  /*     } */
  /*     if ($m->bestTimePlayerId != 0) { */
  /*       $master = $pages->get($m->bestTimePlayerId); */
  /*       $m->bestTimePlayerTitle = $master->title; */
  /*       $m->bestTimeTeam = $master->team->title; */
  /*       if ($m->bestTrainedPlayerId == $player->id) { */
  /*         $m->isMaster = true; */
  /*       } else { */
  /*         $m->isMaster = false; */
  /*       } */
  /*     } */
  /*     $topics = $m->topic->implode(', ', '{title}'); */
  /*     $out .= '<tr>'; */
  /*     $out .= '<td data-search="'.$topics.','.$m->name.'">'; */
  /*     $out .= $m->title; */
  /*     // Find # of days compared to today to set 'New' indicator */
  /*     $date2 = new \DateTime(date("Y-m-d", $m->published)); */
  /*     $interval = $today->diff($date2); */
  /*     if ($interval->days < 7) { */
  /*       $out .= ' <span class="badge">'.__("New").'</span>'; */
  /*     } */
  /*     if ($m->special) { */
  /*       $out .= ' <span class="badge">'.__("Detected").' !</span>'; */
  /*     } */
  /*     $out .= '</td>'; */
  /*     $out .= '<td>'; */
  /*     $out .= $m->level; */
  /*     $out .= '</td>'; */
  /*     $out .= '<td>'; */
  /*     $m->summary == '' ? $summary = '-' : $summary = $m->summary; */
  /*     $out .= $summary; */
  /*     if ($user->language->name != 'french') { */
  /*       $m->of(false); */
  /*       if ($m->summary->getLanguageValue($french) != '') { */
  /*         $out .= ' <span class="glyphicon glyphicon-question-sign" data-toggle="tooltip" data-html="true" title="'.$m->summary->getLanguageValue($french).'"></span>'; */
  /*       } */
  /*     } */
  /*     // Data preview */
  /*     $exData = $m->exData; */
  /*     $allLines = preg_split('/$\r|\n/', $sanitizer->entitiesMarkdown($exData)); */
  /*     $listWords = prepareListWords($allLines, $m->type->name); */
  /*     $out .= ' <span class="glyphicon glyphicon-eye-open" data-toggle="tooltip" data-html="true" title="'.$listWords.'"></span>'; */
  /*     $out .= '</td>'; */
  /*     $out .= '<td>'; */
  /*     if ($user->hasRole('player')) { */
  /*       if ($m->utGain > 0) { */
  /*         $out .= '<span class="label label-success"><span class="glyphicon glyphicon-thumbs-up"></span> +'.$m->utGain.'</span> '; */
  /*       } else { */
  /*         $out .= '<span class="label label-danger"><span class="glyphicon glyphicon-thumbs-down"></span> 0</span> '; */
  /*       } */
  /*     } else { */
  /*       if ($user->isSuperuser()) { */
  /*         $out .= '[Admin]'; */
  /*       } else { */
  /*         $out .= '['.__("Teacher").']'; */
  /*       } */
  /*     } */
  /*     $out .= '</td>'; */
  /*     // Last training session date */
  /*     $out .= '<td>'; */
  /*     if ($user->hasRole('player')) { */
  /*       if ($m->lastTrainingInterval != '-1') { */
  /*         $out .= $m->lastTrainingInterval; */
  /*       } else { */
  /*         $out .= '-'; */
  /*       } */
  /*     } else { */
  /*       if ($user->isSuperuser()) { */
  /*         $out .= '[Admin]'; */
  /*       } else { */
  /*         $out .= '['.__("Teacher").']'; */
  /*       } */
  /*     } */
  /*     $out .= '</td>'; */
  /*     $out .= '<td>'; */
  /*     if ($m->isTrainable == 1) { */
  /*       $out .= ' <a class="btn btn-primary btn-xs" href="'.$m->url.'train"><i class="glyphicon glyphicon-headphones" data-toggle="tooltip" title="'.__("Put the helmet on !").'"></i></a>'; */
  /*     } else { */
  /*       if ($m->waitForTrain == 1) { // Trained today */
  /*         $out .= __('Come back tomorrow ;)'); */
  /*       } else { */
  /*         $out .= sprintf(__("Come back in %d days ;)"), $m->waitForTrain); */
  /*       } */
  /*     } */
  /*     $formerRequest = $pages->get("has_parent=$player, template=event, task.name=fight-vv, inClass=1, refPage=$m, date>$limitDate"); */
  /*     if ($formerRequest->id) { */
  /*       $out .= ' <span class="glyphicon glyphicon-ok" data-toggle="tooltip" title="'.__('You have already defeated this monster in the previous year.').'"></span>'; */
  /*     } else { */
  /*       if ($request == 0) { */
  /*         $msg = sprintf(__("Fight request for %s"), $m->title); */
  /*         $out .= ' <span><a class="btn btn-danger btn-xs fightRequestConfirm" href="'.$page->url.'" data-href="'.$pages->get("name=submitforms")->url.'?form=fightRequest&monsterId='.$m->id.'&playerId='.$player->id.'" data-msg="'.$msg.'" data-reload="true"><i class="glyphicon glyphicon-education" data-toggle="tooltip" title="'.__("Ask teacher for an in-class Fight!").'"></i></a></span>'; */
  /*       } else if ($request == $m->id) { */
  /*         $out .= ' <span class="glyphicon glyphicon-ok-circle" data-toggle="tooltip" title="'.__('Your teacher has already been warned about this request.').'"></span>'; */
  /*       } */
  /*     } */
  /*     $out .= '</td>'; */
  /*     // Find best trained player on this monster */
  /*     $out .= '<td data-sort="'.$m->best.'">'; */
  /*     if ($m->bestTrainedPlayerId != 0) { */
  /*       if ($m->isBestTrained) { $class = 'success'; } else { $class = 'primary'; } */
  /*       $out .= '<span class="label label-'.$class.'">'.$m->best.' '.__("UT").' - '.$m->bestTrainedTitle.' ['.$m->bestTrainedTeam.']</span>'; */
  /*     } else { */
  /*       $out .= '<span>No record yet.</span>'; */
  /*     } */
  /*     $out .= '</td>'; */
  /*     $out .= '<td data-sort="'.$m->masterTime.'">'; */
  /*     if ($m->bestTimePlayerTitle) { */
  /*       if ($m->isMaster) { $class = 'success'; } else { $class = 'primary'; } */
  /*       $out .= '<span class="label label-'.$class.'">'.ms2string($m->masterTime).' '.__('by').' '.$m->bestTimePlayerTitle.' ['.$m->bestTimeTeam.']</span>'; */
  /*     } else { */
  /*       $out .= '-'; */
  /*     } */
  /*     $out .= '</td>'; */
  /*     $out .= '</tr>'; */
  /*   } */
  /* $out .= '</tbody>'; */
  /* $out .= '</table>'; */
  echo $out;
  /* include("./foot.inc"); */
}
?>
