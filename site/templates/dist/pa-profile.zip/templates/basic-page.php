<?php namespace ProcessWire;

include("./head.inc"); 

echo $page->body;

include("./foot.inc"); 

